/*class Tables{
	public static void main(String [] args){
	int mul=0;
	if(args.length==1){
	  int n=Integer.parseInt(args[0]);
		//Tables calculation
	  for(int i=1;i<11;i++){
		mul=n*i;
		System.out.println(n+" X "+i+" = "+mul);
		}
	}else
	System.out.println("Pass One Paramater !!");
}
}*/

// Tables program with Static function 

/*class Tables {
		//static Tables Function
    public static void numberTables(int n) {
        for (int i = 1; i <= 10; i++) {
            int mul = n * i;
            System.out.println(n + " X " + i + " = " + mul);
        }
    }

    public static void main(String[] args) {
        if (args.length == 1) {
            int num = Integer.parseInt(args[0]);
            numberTables(num);
        } else {
            System.out.println("Pass one parameter!!");
        }
    }
}*/

// Tables program with Non-Static function 

class Tables {
		//Non-static Tables Function
    public void numberTables(int n) {
        for (int i = 1; i <= 10; i++) {
            int mul = n * i;
            System.out.println(n + " X " + i + " = " + mul);
        }
    }

    public static void main(String[] args) {
		//Creating obj for Tables class
	Tables T = new Tables();
        if (args.length == 1) {
            int num = Integer.parseInt(args[0]);
		//calling the Non-Static function using obj
            T.numberTables(num);
        } else {
            System.out.println("Pass one parameter!!");
        }
    }
}
