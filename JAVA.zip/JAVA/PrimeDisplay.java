/*class PrimeDisplay{
	public static boolean isPrime(int num){
	for(int i=2;i<num;i++){
		if(num%i == 0)
			return false;
	}return true;
}

    public static void main(String[] args) {
        if (args.length == 3) {
            int num1 = Integer.parseInt(args[0]);
            int num2 = Integer.parseInt(args[1]);
            int num3 = Integer.parseInt(args[2]);

            if (isPrime(num1))
                System.out.println(num1);
	    if(isPrime(num2))
		System.out.println(num2);
	    if(isPrime(num3))
		System.out.println(num3);
        } else {
            System.out.println("Enter 3 input parameters");
        }
    }
}*/




class PrimeDisplay{
	public static void isPrime(int num){
	boolean flag=true;
	for(int i=2;i<num;i++){
		if(num%i == 0)
			flag=false;
	}
		if(flag)
		System.out.println(num);

}

    public static void main(String[] args) {
        if (args.length == 3) {
            for(int j=0;j<3;j++){
		isPrime(Integer.parseInt(args[j]));
}
        } else {
            System.out.println("Enter 3 input parameters");
        }
    }
}





