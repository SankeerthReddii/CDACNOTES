class Factorial{
	public static void main(String [] args){
	
	int sum=1;
	if(args.length==1){
	int n=Integer.parseInt(args[0]);
	for(int i=1;i<=n;i++){
		sum=sum*i;
	     }
	System.out.println("The Factorial is : "+sum);
	}else
	System.out.println("Pass One Parameter !!");
}
}