/*import java.util.Scanner;
class OddNumbers{
	public static void main(String [] args){
	
	Scanner s = new Scanner(System.in);
	System.out.println("Enter a number : ");
	int num = s.nextInt();

		// Claculate Odd Numbers
	for(int i=0;i<num;i++){
	   if(i%2 != 0)
		System.out.println(i);
		}
	}
}*/

//importing the scanner from the below package
import java.util.Scanner;
class OddNumbers{
		// Odd Number function
	public static void oddNumbers(int num){
		//Logic of Odd Numbers
	for(int i=0;i<num;i++){
	   if(i%2 != 0)
		System.out.println(i);
		}
}

	public static void main(String [] args){
		//Creating obj for Scanner 
	Scanner s = new Scanner(System.in);
	System.out.println("Enter a number : ");
	int num = s.nextInt();

		//Odd Numbers function calling
	oddNumbers(num);
	}
}