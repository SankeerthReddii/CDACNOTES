import java.util.Scanner;

public class Assignment_Day1_1 {

	public static boolean isPrime(int num) {
		for(int i=2;i<num;i++) {
			if(num%i==0)
				return false;
		}
		return true;
	}
	
	public static void checkPrime(int num) {
		if(isPrime(num)) {
				System.out.println("The Number is Prime : ");
			for(int i=1;i<11;i++) {
				
				System.out.println(num+" x "+i+" = "+num*i);
			}
		}else {
			System.out.println(num+" is Not prime : ");
			System.out.print("The Number divided by 10 : ");
			System.out.println(num/10);
		}
		
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	if(args.length==3){
			int num1=Integer.parseInt(args[0]);
			int num2=Integer.parseInt(args[1]);
			int num3=Integer.parseInt(args[2]);
			
			checkPrime(num1);
			checkPrime(num2);
			checkPrime(num3);
		}else{
			System.out.println("Enter 3 Parameter's Only");
		}
	}

}
