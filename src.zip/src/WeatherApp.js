import React, { useState } from "react";
import { Container,Alert} from "react-bootstrap";

const API_KEY = "8495bbeeb55b4d2eb65131752252005";

export function WeatherApp() {
  const [city, setCity] = useState("");
  const [weather, setWeather] = useState(null);
  const [error, setError] = useState("");

  const getWeather = async () => {
    setError("");
    setWeather(null);
    if (!city) {
      setError("Please enter a city name.");
      return;
    }
    try {
      const response = await fetch(
        `https://api.weatherapi.com/v1/current.json?key=${API_KEY}&q=${city}&aqi=no`
      );
      if (!response.ok) {
        throw new Error("City not found or API error.");
      }
      const data = await response.json();
      setWeather(data);
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="container mt-5">
        <Container>
                <Alert variant="primary"><h1>Current Weather Updates</h1></Alert>
                <p>Search your city and try </p>
            </Container>
      <div className="row">
        <div className="col-lg-4">
          <label className="form-label">CITY</label>
          <input
            type="text"
            className="form-control"
            value={city}
            onChange={(e) => setCity(e.target.value)}
            placeholder="Enter city name"
          />
          <button
            className="btn btn-primary mt-5"
            onClick={getWeather}
            type="button"
          >
            Fetch Weather
          </button>

          <div id="weatherResult" className="mt-4">
            {error && (
              <div className="alert alert-danger p-2">{error}</div>
            )}
            {weather && (
              <div>
                <h5>Humidity : {weather.current.humidity}</h5>
                <h5>Temperature : {weather.current.temp_f}</h5>
                <h5>Wind Speed : {weather.current.wind_kph}</h5>
                <h5>{weather.current.condition.text}</h5>
                <img src={weather.current.condition.icon} alt="weather icon" />
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

