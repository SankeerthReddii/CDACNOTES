import { useEffect, useState } from "react";
import { Container, Alert, Col, Row, Card } from "react-bootstrap";
export function AllNews() {
    const [NewsArticles, setNewsArticles] = useState([])
    useEffect(() => {
        fetch('https://newsapi.org/v2/top-headlines?sources=techcrunch&apiKey=2414b459955748de9757872d40378514').then((Response) => {
            Response.json().then((data) => {
                console.log(data);
                console.log(data.articles);
                setNewsArticles(data.articles);
            })
        }).catch((error) => {
            console.log(error);
        })
    }, [])
    return (
        <Container className="mt-3">
            <Container>
                <Alert variant="primary"><h1>welcome to AllNews Section</h1></Alert>
                <p>The Trending News all over the Globe</p>
            </Container>
            <Container className="mt-3" lg={4}>
                <Row>
                <table className="table">
                    <thead>
                        <tr>
                            <th scope="col">Image</th>
                            <th scope="col">Title</th>
                            <th scope="col">Information</th>
                        </tr>
                    </thead>
                    <tbody>
                        {NewsArticles.map((article) => (
                            <tr key={article.title}>
                                <td>
                                    <img src={article.urlToImage} 
                                         className="img-fluid mr-3" 
                                         alt="Responsive image"
                                         width={2100} height={1100} />
                                </td>
                                <td>{article.title}</td>
                                <td>{article.description}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </Row>

            </Container>

        </Container>

    )
}

// https://newsapi.org/v2/top-headlines?sources=techcrunch&apiKey=2414b459955748de9757872d40378514