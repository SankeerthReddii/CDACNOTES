import { Component } from "react";
export class UserData extends Component{
    constructor(){
        super();
        this.state={
            user:[]
        }
    }
    render(){
        return(
            <div>
                <h1>List of Users</h1>
                <table border={1}cellPadding={10}>
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th>Name</th>
                            <th>Email</th>
                        </tr>
                    </thead>
                <tbody>

                </tbody>
                </table>
            </div>
        );
    }
    componentDidMount(){
        fetch('https://jsonplaceholder.typicode.com/users').then((response)=>{
            response.json().then((data)=>{
                this.setState({users:data})
            })
        }).catch((error)=>{
            console.log(error);
        })
        
    }
}