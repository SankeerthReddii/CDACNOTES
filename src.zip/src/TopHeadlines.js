import { useEffect, useState } from "react";
import { Container,Alert,Col,Row,Card } from "react-bootstrap";
export function TopHeadlines() {
    const[NewsArticles,setNewsArticles]=useState([])
    useEffect (()=>{
        fetch('https://newsapi.org/v2/top-headlines?country=us&category=business&apiKey=2414b459955748de9757872d40378514').then((Response)=>{
            Response.json().then((data)=>{
                console.log(data);
                console.log(data.articles);
                setNewsArticles(data.articles);
            })
        }).catch((error)=>{
            console.log(error);
        })
    },[])
    
    return (
        <Container className="mt-3">
            <Container>
                <Alert variant="primary"><h1>welcome to Top headlines</h1></Alert>
                <p>These are Today's Trending News </p>
            </Container>
            <Container className="mt-3" lg={6}>
                
                
                    {
                        NewsArticles.map((article) => {
                            return (
                                <Row>
                                <Col lg={6} >
                                    <Card>
                                        <Card.Img variant="top" src={article.urlToImage} />
                                        <Card.Body>
                                            <Card.Title>{article.Title}</Card.Title>
                                            <Card.Text>
                                                {article.description}
                                            </Card.Text>

                                        </Card.Body>
                                    </Card>
                                </Col>
                                </Row>
                            )
                        })
                    }

            </Container>
        
                    {/* </div> */}
        </Container>
    )
}