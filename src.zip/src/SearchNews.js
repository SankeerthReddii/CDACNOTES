import { Container, Card, Col, Row } from "react-bootstrap";
import { useState } from "react";

export function SearchNews() {
    const [NewsArticles, setNewsArticles] = useState([]);


    const search = async () => {
        const value = document.getElementById("news").value;

        const response = await fetch(`https://newsapi.org/v2/everything?q=${value}&apiKey=2414b459955748de9757872d40378514`);
        Response.json().then((data) => {
            console.log(data);
            console.log(data.articles);
            setNewsArticles(data.articles);
        })
    };

    return (
        <div>
            <div id="main">
                <input type="text" placeholder="search" id="news"></input>
                <button type="button" class="btn btn-primary" onClick={search}>Primary</button>
            </div>
            <Container>
                {
                    NewsArticles.map((article) => {
                        return (
                            <Row>
                                <Col lg={6} >
                                    <Card>
                                        <Card.Img variant="top" src={article.urlToImage} />
                                        <Card.Body>
                                            <Card.Title>{article.Title}</Card.Title>
                                            <Card.Text>
                                                {article.description}
                                            </Card.Text>

                                        </Card.Body>
                                    </Card>
                                </Col>
                            </Row>
                        )
                    })
                }
            </Container>
        </div>
    )
}