import logo from './logo.svg';
import './App.css';
import {BrowserRouter, Routes, Route} from "react-router-dom"
import { NavBar } from './NavBar';
import { TopHeadlines } from './TopHeadlines';
import { AllNews } from './AllNews';
import {WeatherApp} from './WeatherApp';
import { SearchNews } from './SearchNews';


function App() {
  return (
    <BrowserRouter>
    <div>
      <NavBar></NavBar>
      <Routes>
        <Route path='/' element={<SearchNews></SearchNews>}></Route>
        <Route path="/top" element={<TopHeadlines></TopHeadlines>}></Route>
        <Route path="/all-news" element={<AllNews></AllNews>}></Route>
        <Route path='/weather' element={<WeatherApp></WeatherApp>}></Route>
      </Routes>
    </div>
    </BrowserRouter>
  );
}

export default App;
